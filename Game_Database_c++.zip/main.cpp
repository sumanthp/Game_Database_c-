            #include <iostream>
            #include<fstream>
            #include<cstdlib>
            #include<string.h>

            using namespace std;

    //creation of games record
            struct games{
            int sl;
            char name[20];
            int year;
            char platform[20];
            char company[20];
            }g[10];
            int i,j,n,n1,found=0;
            char ch;
    FILE *fptr;



    //function used to write company data to a file
            void company_data(){
            fptr=fopen("company.txt","w");
        if(!fptr)
            cout<<"error!!!file cannot be opened"<<endl;

            cout<<"Enter number of companies\n";
            cin>>n1;
            cout<<"Enter company names"<<endl;
            for(i=0;i<n1;i++){
                cin>>g[i].company;
    fprintf(fptr,"%d\n",g[i].company);

            }

    fclose(fptr);
            }


    //function used to read company data from the file
            void company_read_data(){
            fptr=fopen("company.txt","r");
            if(!fptr)
                cout<<"error!!!file cannot be opened"<<endl;

            for(i=0;i<n1;i++){
                cout<<g[i].company<<endl;

            }
    fclose(fptr);

            }


    //function used to  write contents to the game file
            void write_to_file(){
            fptr=fopen("games.txt","w");
            if(!fptr)
                cout<<"error!!!file cannot be opened"<<endl;
                cout<<"Enter \n a - to input game data \n b - to input Company data\n";
                cin>>ch;
            switch(ch){

            case 'a':cout<<"Enter num of games\n";
            cin>>n;

            for(i=0;i<n;i++){
            cout<<"Enter Sl no.\n";
            cin>>g[i].sl;
            cout<<"\nEnter name of the game"<<endl;
            cin>>g[i].name;
            cout<<"\nEnter year of release"<<endl;
            cin>>g[i].year;
            cout<<"\nEnter platform"<<endl;
            cin>>g[i].platform;
    fprintf(fptr," %d %s %d %s\n",g[i].sl,g[i].name,g[i].year,g[i].platform);


            }
            break;

            case 'b': company_data();
            break;

            default: cout<<"Please enter appropriate details\n";
            return;
            break;
            }
            fclose(fptr);
            }


    //function to read contents from the games file
            void read_from_file(){
             fptr=fopen("games.txt","r");
            if(!fptr)
                cout<<"error openeing file"<<endl;

            cout<<"Enter c to read game data or enter d to read company data\n";
            cin>>ch;
            switch(ch){
            case 'c':
            for(i=0;i<n;i++){
               cout<<g[i].sl<<" "<<g[i].name<<" "<<g[i].year<<" "<<g[i].platform<<endl;


            }
            break;

            case 'd':company_read_data();
            break;

            default: cout<<"Enter appropriate input\n";
            return;
            break;
            }
    fclose(fptr);
            }

            void search_for_game(){
                fptr=fopen("games.txt","r");
                if(!fptr)
                    cout<<"error!!!file cannot be opened"<<endl;
                int y;
                char p[20];
            cout<<"Enter the parameters to search\n";
            cout<<"platform and year of release:\n";
            cin>>p;
            cin>>y;
            for(int i=0;i<n;i++){
            if(g[i].year==y&&strcmp(g[i].platform,p)==0){
                    found =1;
                      cout<<g[i].sl<<" "<<g[i].name<<" "<<g[i].year<<" "<<g[i].platform<<endl;

            }

            }
            if(found==0)
                cout<<"Game not found in database"<<endl;
    fclose(fptr);
            }


    //function which displays the main menu
            void mainmenu(){
                int choice;
                do{
             cout<<" \n1 - WRITE\n2 - READ\n3 - MAIN MENU \n4 - SEARCH\n5 - DELETE\n6 - EXIT\n";
                cin>>choice;
                cout<<endl;


                switch(choice){

                 case 1: write_to_file();
                break;

                case 2: read_from_file();
                break;

                case 3: mainmenu();
                break;

                case 4: search_for_game();
                cout<<endl;
                break;

                 case 5: remove("games.txt");
                 cout<<endl;
            break;

            case 6: exit(0);


                }

            }while(choice!=4);
            }


    //main function
            int main()
            {


                cout<<"**************************************************"<<endl;
                cout<<" DataBase which holds the records of games"<<endl;
                cout<<endl;


                mainmenu();
                cout<<endl;


                return 0;
            }
